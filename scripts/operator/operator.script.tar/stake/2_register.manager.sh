source /home/ubuntu/variables.list

/home/ubuntu/plasma-evm/build/bin/geth staking register \
            --datadir $DATADIR \
            --rootchain.url ws://$ROOTCHAIN_IP:8546 \
            --operator $OPERATOR
