#!/usr/bin/env bash
source /home/ubuntu/variables.list

echo "$OPERATOR_PASSPHRASE" > /home/ubuntu/signer.pass
echo "signer.pass created"
