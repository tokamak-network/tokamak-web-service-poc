#!/usr/bin/env bash
source /home/ubuntu/variables.list

# Deploy contracts at rootchain
echo "Deploy rootchain contract and others"
nohup /home/ubuntu/plasma-evm/build/bin/geth \
    --rootchain.url "ws://$ROOTCHAIN_IP:8546" \
    --operator.key $OPERATOR_KEY \
    --datadir $DATADIR \
    --nousb \
    deploy "/home/ubuntu/genesis.json" $CHAIN_ID $PRE_ASSET $EPOCH > deploy.rootchain.log &
sleep 2
echo "rootchain contract deployed!"
# deploy params : chainID, isInitialAsset, Epochlength
# you can checkout "$geth deploy --help" for more information
