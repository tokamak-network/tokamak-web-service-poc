kill -9 `ps aux | grep geth | awk '{print $2}'`

rm -r chaindata-oper/ deploy.rootchain.log init.oper.log signer.pass operator.log genesis.json
