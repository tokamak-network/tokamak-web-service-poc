source /home/ubuntu/variables.list

/home/ubuntu/plasma-evm/build/bin/geth staking getManagers --datadir $DATADIR2
