source /home/ubuntu/account.variable

/home/ubuntu/plasma-evm/build/bin/geth staking getManagers manager.json \
  --datadir $DATADIR2
