source /home/ubuntu/account.variable

/home/ubuntu/plasma-evm/build/bin/geth staking startPowerTON \
            --datadir $DATADIR2 \
            --rootchain.url ws://127.0.0.1:8546 \
            --dev.key $OPERATOR_PRIV_KEY \
            --operator $OPERATOR
