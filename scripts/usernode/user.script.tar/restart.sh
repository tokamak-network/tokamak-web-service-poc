kill -9 `ps aux | grep geth | awk '{print $2}'`
rm -r /home/ubuntu/chaindata-user user.log init.user.log
/home/ubuntu/1_init.user.sh
sleep 2
/home/ubuntu/2_run.user.sh
